#!bin/bash

#compile
make

#tests
./a.out <blank.in 1>test1.out 2>test1.err 
./a.out doesnotexist 1>test2.out 2>test2.err
./a.out locked.in 1>test3.out 2>test3.err
./a.out -c <blank.in 1>test4.out 2>test4.err
./a.out test.in 1>test5.out 2>test5.err
./a.out <testSTD.in 1>test6.out 2>test6.err
./a.out -w test.in -c 1>test7.out 1>test7.err
./a.out -w test.in -c -l 1>test8.out 2>test8.err
./a.out white.in 1>test9.out 2>test9.err


#compare tests
#test 1
diff -q test1.out test1.expect
diff -q test1.err test1.errex
diff test1.out test1.expect
diff test1.err test1.errex
#test 2
diff -q test2.out test2.expect
diff -q test2.err test2.errex
diff test2.out test2.expect
diff test2.err test2.errex
#test 3
diff -q test3.out test3.expect
diff -q test3.err test3.errex
diff test3.out test3.expect
diff test3.err test3.errex
#test 4
diff -q test4.out test4.expect
diff -q test4.err test4.errex
diff test4.out test4.expect
diff test4.err test4.errex
#test 5
diff -q test5.out test5.expect
diff -q test5.err test5.errex
diff test5.out test5.expect
diff test5.err test5.errex
#test 6
diff -q test6.out test6.expect
diff -q test6.err test6.errex
diff test6.out test6.expect
diff test6.err test6.errex
#test 7
diff -q test7.out test7.expect
diff -q test7.err test7.errex
diff test7.out test7.expect
diff test7.err test7.errex
#test 8
diff -q test8.out test8.expect
diff -q test8.err test8.errex
diff test8.out test8.expect
diff test8.err test8.errex
#test 9
diff -q test9.out test9.expect
diff -q test9.err test9.errex
diff test9.out test9.expect
diff test9.err test9.errex
