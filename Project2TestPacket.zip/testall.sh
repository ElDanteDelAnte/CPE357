#!/bin/bash

#create locked file
touch locked.in
chmod a-rw locked.in

function findpipe
{
   local index=-1

   return index
}

#test arguments
targ[1]="< blank.in"
targ[2]="doesnotexist"
targ[3]="-c locked.in"
targ[4]="-c < blank.in"
targ[5]="test.in"
targ[6]="< testSTD.in"
targ[7]="-w test.in -c"
targ[8]="-w test.in -c -l"
targ[9]="white.in"
targ[10]="test.in cat.in"
targ[11]="cat.in doesnotexist test.in locked.in"
targ[12]="-l -L test.in"

#generate expects
#tests

~kmammen/357/Project2/swc <blank.in 1>test1.expect 2>test1.errex
rvx[1]=$?
~kmammen/357/Project2/swc doesnotexist 1>test2.expect 2>test2.errex
rvx[2]=$?
~kmammen/357/Project2/swc locked.in 1>test3.expect 2>test3.errex
rvx[3]=$?
~kmammen/357/Project2/swc -c <blank.in 1>test4.expect 2>test4.errex
rvx[4]=$?
~kmammen/357/Project2/swc test.in 1>test5.expect 2>test5.errex
rvx[5]=$?
~kmammen/357/Project2/swc <testSTD.in 1>test6.expect 2>test6.errex
rvx[6]=$?
~kmammen/357/Project2/swc -w test.in -c 1>test7.expect 1>test7.errex
rvx[7]=$?
~kmammen/357/Project2/swc -w test.in -c -l 1>test8.expect 2>test8.errex
rvx[8]=$?
~kmammen/357/Project2/swc white.in 1>test9.expect 2>test9.errex
rvx[9]=$?
~kmammen/357/Project2/swc test.in cat.in 1>test10.expect 2>test10.errex
rvx[10]=$?
~kmammen/357/Project2/swc cat.in doesnotexist test.in locked.in 1>test11.expect 2>test11.errex
rvx[11]=$?
~kmammen/357/Project2/swc -l -L test.in 1>test12.expect 2>test12.errex
rvx[12]=$?

#compile
make clean
make

#test own program
#rewrite directory as needed (sorry there are so many, nothing else worked)
~/cpe357/Project2/a.out <blank.in 1>test1.out 2>test1.err 
rvo[1]=$?
~/cpe357/Project2/a.out doesnotexist 1>test2.out 2>test2.err
rvo[2]=$?
~/cpe357/Project2/a.out locked.in 1>test3.out 2>test3.err
rvo[3]=$?
~/cpe357/Project2/a.out -c <blank.in 1>test4.out 2>test4.err
rvo[4]=$?
~/cpe357/Project2/a.out test.in 1>test5.out 2>test5.err
rvo[5]=$?
~/cpe357/Project2/a.out  <testSTD.in 1>test6.out 2>test6.err
rvo[6]=$?
~/cpe357/Project2/a.out  -w test.in -c 1>test7.out 1>test7.err
rvo[7]=$?
~/cpe357/Project2/a.out  -w test.in -c -l 1>test8.out 2>test8.err
rvo[8]=$?
~/cpe357/Project2/a.out  white.in 1>test9.out 2>test9.err
rvo[9]=$?
~/cpe357/Project2/a.out  test.in cat.in 1>test10.out 2>test10.err
rvo[10]=$?
~/cpe357/Project2/a.out  cat.in doesnotexist test.in locked.in 1>test11.out 2>test11.err
rvo[11]=$?
~/cpe357/Project2/a.out  -l -L test.in 1>test12.out 2>test12.err
rvo[12]=$?


#check exit conditions
function checkExit
{
   local exp=${rvx[$1]}
   local out=${rvo[$1]}
   if [[ $exp != $out ]]; then
      echo "Test $1 exited $out, should be $exp "
   fi
}

#compare tests
function compare
{
   name="test$1"
   diff -q $name.out $name.expect
   diff $name.out $name.expect
   diff -q $name.err $name.errex
   diff $name.err $name.expect
   checkExit $1
}

#compare all tests
for t in `seq 1 12`;
do
   compare $t
done


